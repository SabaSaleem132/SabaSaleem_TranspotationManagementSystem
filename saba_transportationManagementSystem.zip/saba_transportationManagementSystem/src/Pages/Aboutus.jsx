import React from "react";
const Aboutus=()=>{
return(
    <>
    <h1>Let's Explore together</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita quod, incidunt nemo veniam culpa possimus quo. Reiciendis, cupiditate ipsa reprehenderit amet maxime dolorem nihil saepe, pariatur quam molestias aliquam suscipit eius odio quod illo. Asperiores magni officiis rem excepturi delectus culpa, eligendi dignissimos. Cupiditate asperiores sint numquam obcaecati at fugiat?</p>
    </>
)
}
export default Aboutus;