import React from "react";
const Home=()=>{
return(<>
<h1>Welcome to Lahore</h1>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Autem iste consequuntur tempora rem illo reiciendis repudiandae provident et numquam facilis esse maiores earum, magni natus, placeat, neque cumque veritatis. Nesciunt, reprehenderit! Voluptates ut sunt magni autem nesciunt eligendi ab eos?</p>
</>)
}
export default Home;