import React from "react";
const Contact=()=>{
return(
    <>
    <h1>Contact Us</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint, distinctio excepturi? Sunt nobis suscipit est dolores. Animi nihil quasi fugiat sapiente, minus adipisci officiis quae debitis vitae magni aliquid nobis.</p>
    </>
)
}
export default Contact;