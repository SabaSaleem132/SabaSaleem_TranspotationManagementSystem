import './App.css';
import Navbar from './Components/Navbar';
import Carousel from './Components/Carousel';
import { Route, Routes } from 'react-router-dom';
import Home from './Pages/Home';
import Aboutus from './Pages/Aboutus';
import Contact from './Pages/contact';
function App() {
  return (
    <>
    <Navbar/>
    <Carousel/>
    <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/about' element={<Aboutus/>}></Route>
      <Route path='/contact' element={<Contact/>}></Route>

    </Routes>
    </>
  );
}

export default App;
